<?php
require_once('../tpl/article-save-success.tpl.php');
?>