<?php

setcookie("user_id", 101);

var_dump($_COOKIE);

?>