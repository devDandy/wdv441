<?php
session_start();

require_once("../../tpl/user/user-login-success.tpl.php");

?>

